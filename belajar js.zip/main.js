let hari = new Date().getDay()
alert ("hari ini adalah hari ke " + hari)
alert ("selamat datang")

btn1.style.border = 'none'
btn1.style.padding = '1px'
btn1.style.fontSize = '24px'
btn1.style.background = 'aqua'

